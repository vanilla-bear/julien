# Menu Link Attributes

> Allows you to add attributes to your menu links.

## Installation

1. Install the module the [drupal way](https://www.drupal.org/documentation/install/modules-themes/modules-8)
2. Edit a menu item and edit attributes
3. Add more attributes if needed on configuration page

## Contributing

Pull requests and stars are always welcome. For bugs and feature requests, [please create an issue](https://github.com/yannickoo/menu_link_attributes/issues/new).
